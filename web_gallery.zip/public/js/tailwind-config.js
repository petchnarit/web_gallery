// แยก Tailwind config ออกมา (โหลดหลัง tailwindcdn)
tailwind.config = {
  theme: {
    extend: {
      fontFamily: {
        sans: ['"Noto Sans Thai"', 'ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'sans-serif'],
      },
    },
  },
};
