// import '../css/app.css'
import './gallery'

console.log('CI4 + Vite ready 🚀')
